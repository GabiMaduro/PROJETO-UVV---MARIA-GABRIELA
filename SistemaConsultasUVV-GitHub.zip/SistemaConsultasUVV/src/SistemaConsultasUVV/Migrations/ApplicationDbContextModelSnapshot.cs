using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata;
using SistemaConsultasUVV.Data;

#nullable disable

namespace SistemaConsultasUVV.Migrations;

[DbContext(typeof(ApplicationDbContext))]
partial class ApplicationDbContextModelSnapshot : ModelSnapshot
{
    protected override void BuildModel(ModelBuilder modelBuilder)
    {
#pragma warning disable 612, 618
        modelBuilder
            .HasAnnotation("ProductVersion", "8.0.8")
            .HasAnnotation("Relational:MaxIdentifierLength", 128);

        SqlServerModelBuilderExtensions.UseIdentityColumns(modelBuilder);

        modelBuilder.Entity("SistemaConsultasUVV.Models.Consulta", b =>
        {
            b.Property<int>("Id").ValueGeneratedOnAdd().HasColumnType("int")
                .HasAnnotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn);
            b.Property<DateTime>("DataHora").HasColumnType("datetime2");
            b.Property<string>("Descricao").IsRequired().HasMaxLength(500).HasColumnType("nvarchar(500)");
            b.Property<string>("Especialidade").IsRequired().HasMaxLength(100).HasColumnType("nvarchar(100)");
            b.Property<int>("UsuarioId").HasColumnType("int");
            b.HasKey("Id");
            b.HasIndex("UsuarioId");
            b.ToTable("Consultas");
        });

        modelBuilder.Entity("SistemaConsultasUVV.Models.Usuario", b =>
        {
            b.Property<int>("Id").ValueGeneratedOnAdd().HasColumnType("int")
                .HasAnnotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn);
            b.Property<DateTime>("DataCadastro").ValueGeneratedOnAdd().HasColumnType("datetime2").HasDefaultValueSql("GETUTCDATE()");
            b.Property<string>("Email").IsRequired().HasMaxLength(150).HasColumnType("nvarchar(150)");
            b.Property<string>("Nome").IsRequired().HasMaxLength(100).HasColumnType("nvarchar(100)");
            b.Property<string>("SenhaHash").IsRequired().HasMaxLength(500).HasColumnType("nvarchar(500)").HasColumnName("Senha");
            b.HasKey("Id");
            b.HasIndex("Email").IsUnique();
            b.ToTable("Usuarios");
        });

        modelBuilder.Entity("SistemaConsultasUVV.Models.Consulta", b =>
        {
            b.HasOne("SistemaConsultasUVV.Models.Usuario", "Usuario")
                .WithMany("Consultas")
                .HasForeignKey("UsuarioId")
                .OnDelete(DeleteBehavior.Cascade)
                .IsRequired();
            b.Navigation("Usuario");
        });

        modelBuilder.Entity("SistemaConsultasUVV.Models.Usuario", b =>
        {
            b.Navigation("Consultas");
        });
#pragma warning restore 612, 618
    }
}
