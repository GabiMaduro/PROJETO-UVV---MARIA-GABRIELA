# Roteiro sugerido para o vídeo demonstrativo

Duração recomendada: **3 a 5 minutos**.

1. Apresente rapidamente o objetivo do Sistema de Gestão de Consultas UVV.
2. Mostre no repositório as pastas `Models`, `Views`, `Controllers`, `Data` e `Migrations`.
3. Abra `Program.cs` e destaque:
   - injeção do `ApplicationDbContext`;
   - autenticação por cookie;
   - `UseAuthentication()` antes de `UseAuthorization()`.
4. Execute a aplicação e crie um novo usuário.
5. Saia da conta e entre novamente para demonstrar o login.
6. Cadastre uma consulta com especialidade, data/hora e descrição.
7. Mostre a listagem e a tela de detalhes.
8. Edite a consulta e confirme a alteração.
9. Exclua a consulta e confirme que ela saiu da listagem.
10. Abra uma janela anônima e tente acessar `/Consultas` para mostrar o redirecionamento ao login.
11. Finalize mostrando o banco SQL Server e as tabelas `Usuarios` e `Consultas` (opcional, mas recomendado).

Após publicar o vídeo, substitua no `README.md` o marcador `COLE_AQUI_O_LINK_DO_VIDEO` pelo endereço real.
